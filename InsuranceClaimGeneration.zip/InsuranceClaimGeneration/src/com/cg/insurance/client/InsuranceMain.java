package com.cg.insurance.client;

import java.io.IOException;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;


import com.cg.insurance.bean.InsuranceClaimBean;
import com.cg.insurance.bean.UserBean;
import com.cg.insurance.exception.InsuranceClaimException;
import com.cg.insurance.service.IInsuranceService;
import com.cg.insurance.service.InsuranceServiceImpl;

public class InsuranceMain {
	static Scanner sc=new Scanner(System.in);
	static UserBean userbean=null;
	static InsuranceClaimBean claimBean=null;
	static IInsuranceService iInsuranceService=null;
	static InsuranceServiceImpl insuranceServiceImpl=null;
	
public static void main(String[] args) throws IOException, SQLException, InsuranceClaimException {
	again:while(true) {
	userbean = new UserBean();
	String rolecode=null;
	System.out.println("Enter Your Credentials to use your facility: ");
	System.out.println("Enter your Username: ");
	userbean.setUsername(sc.next());
	System.out.println("Enter your Password: ");
	userbean.setPassword(sc.next());
	
	
	iInsuranceService = new InsuranceServiceImpl();
	try {
	rolecode=iInsuranceService.checkAccess(userbean);
	}
	catch (InsuranceClaimException e) {
		System.err.println(e.getMessage() + " \n Want to Try again..????(y/n)");
		//System.exit(0);
		String cond=sc.next();
		if(cond.equals("y")||cond.equals("Y")) {
		continue again;
		}else {
			System.exit(0);
		}
		
	}
	int option;
	switch (rolecode.toLowerCase()) {
	case "insured":
		
		while(true)
		{
				System.out.println("\n----------------Welcome User--------------------\n");
				System.out.println("1.Create Claim as per Your Policies.");
				System.out.println("2.View Claim.");
				System.out.println("3.Exit.\n");
				
				try {
					option = sc.nextInt();
					switch (option) {
					case 1:
						
						break;
					case 2:
						
						break;
					case 3:
						System.exit(0);
						break;
					default:
						System.out.println("Please Select only from above options");
						break;
					}
				}                         
				catch (InputMismatchException e) {
						sc.nextLine();
						System.out.println("Please enter only Numeric Value.");
				}
				finally {
					
				}
		}	
		
	case "agent":
		while(true)
		{
			System.out.println("\n-------------------Welcome Agent----------------\n");
			System.out.println("1.Create Claim for Your Customers.");
			System.out.println("2.View Claim of your Customers.");
			System.out.println("3.Exit.\n");
			try {
				option = sc.nextInt();
				switch (option) {
				case 1:
					
					break;
				case 2:
					
					break;
				case 3:
					System.exit(0);
					break;
				default:
					System.out.println("Please Select only from above options");
					break;
				}
			}                         
			catch (InputMismatchException e) {
					sc.nextLine();
					System.out.println("Please enter only Numeric Value.");
			}   
	    }	
		
	case "admin":
		while(true)
		{
			System.out.println("\n-------------------Welcome Admin----------------\n");
			System.out.println("1.Create Profile.");
			System.out.println("2.Create Claim for any customer.");
			System.out.println("3.View Claim of any customer.");
			System.out.println("4.Generate Report.");
			System.out.println("5.Exit.\n");
			try {
				option = sc.nextInt();
				switch (option) {
				case 1:
						userbean=null;
						while(userbean==null) {
						userbean = populateUserBean();
						}
						try {
							iInsuranceService = new InsuranceServiceImpl(); 
							iInsuranceService.addUser(userbean);
							
							System.out.println("User Profile has been Succcessfully Created !!!! ");

						} catch (InsuranceClaimException insuranceException) {
							
							System.err.println("ERROR : "+ insuranceException.getMessage());
						} finally {
							userbean = null;
							iInsuranceService = null;
							
						}
						
					break;
				case 2:
					
					break;
				case 3:
					
					break;
				case 4:
	
					break;
				case 5:
					System.exit(0);
					break;
				default:
					System.out.println("Please Select only from above options");
					break;
				}
			}                         
			catch (InputMismatchException e) {
					sc.nextLine();
					System.out.println("Please enter only Numeric Value.");
			}   
	}	
	default:
		System.out.println("Please Select only from above options");
		break;
	}
	
	}
	
}

private static UserBean populateUserBean() {
	userbean = new UserBean();
	System.out.println("-------------\tProfile Creation Menu\t--------------------\n");
	System.out.println("Enter Details:\n");
	System.out.println("Enter Username U want to give: ");
	userbean.setUsername(sc.next());
	System.out.println("Enter Password that u want to give: ");
	userbean.setPassword(sc.next());
	System.out.println("Select from below Roles for which you want to create profile:");
	System.out.println("1.Insured");
	System.out.println("2.Agent");
	System.out.println("3.Admin");
	try {
		String roleCode=null;
		int option = sc.nextInt();
		switch (option) {
		case 1:
			roleCode="Insured";
			break;
		case 2:
			roleCode="Agent";	
			break;
		case 3:
			roleCode="Admin";	
			break;
		default:
			System.err.println("Select Only from Above Option\n");
			break;
		}
		userbean.setRoleCode(roleCode);
		if(roleCode!=null) {
			insuranceServiceImpl=new InsuranceServiceImpl();
			try {
				insuranceServiceImpl.validateUserDetails(userbean);
				return userbean;
			} catch(InsuranceClaimException insuranceException) {
				
				System.err.println("Invalid data:");
				System.err.println(insuranceException.getMessage() + " \n Want to Try again..????(y/n)");
				String cond=sc.next();
				if(!(cond.equals("y")||cond.equals("Y"))) {
					System.exit(0);
				}

			}
			
		}
		
	} catch (InputMismatchException inputMismatchException) {
		sc.nextLine();
		System.err.println("Please enter a numeric value for Roles");
		}
	return null;
}
}
