package com.cg.insurance.bean;

public class InsurancePolicyDetails {
private long policy_Number;
private String questionID;
private String answer;
public long getPolicy_Number() {
	return policy_Number;
}
public void setPolicy_Number(long policy_Number) {
	this.policy_Number = policy_Number;
}
public String getQuestionID() {
	return questionID;
}
public void setQuestionID(String questionID) {
	this.questionID = questionID;
}
public String getAnswer() {
	return answer;
}
public void setAnswer(String answer) {
	this.answer = answer;
}

}
